package com.example.controller;

import java.sql.SQLException;
import java.util.ArrayList;
import java.util.Arrays;
import java.util.List;
import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.http.HttpStatus;
import org.springframework.http.ResponseEntity;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;
import org.springframework.web.servlet.ModelAndView;

import com.example.dto.CartDTO;
import com.example.dto.GoodsDTO;
import com.example.dto.MemberDTO;
import com.example.dto.OrderDTO;
import com.example.service.CartService;
import com.example.service.GoodsService;

@Controller
public class GoodsController {

	@Autowired
	CartService cartService;

	@Autowired
	GoodsService goodsService;
	
	@RequestMapping("/cartOrderAllDone")//카트 번호를 이용한 다건 결제 처리
	public String cartOrderAllDone(HttpServletRequest request,
			HttpSession session, Model m) throws SQLException {
		String[] nums = request.getParameterValues("num");
		String userid = request.getParameter("userid");
		String ordername = request.getParameter("orderName");
		String post = request.getParameter("post");
		String addr1 = request.getParameter("addr1");
		String addr2 = request.getParameter("addr2");
		String phone = request.getParameter("phone");
		String payMethod = request.getParameter("payMethod");
		
		List<OrderDTO> orderDTOs = new ArrayList<>();
		for (int i = 0; i < nums.length; i++) {
			OrderDTO dto = new OrderDTO();
			dto.setNum(0);
			dto.setUserid(userid);
			dto.setOrderName(ordername);
			dto.setPost(post);
			dto.setAddr1(addr1);
			dto.setAddr2(addr2);
			dto.setPhone(phone);
			dto.setPayMethod(payMethod);
			orderDTOs.add(dto);
		}

		cartService.orderAllDone(orderDTOs, Arrays.asList(nums));
		System.out.println(orderDTOs);
		m.addAttribute("orderAllDone", orderDTOs);
		
		return "orderAllDone";
	}

	@RequestMapping("/cartOrderAllConfirm")//카트 상품, 선택된 모든 카트번호를 이용한 다건 주문
	public String cartOrderAllConfirm(HttpServletRequest request, HttpSession session, Model m) {
		String[] checks = request.getParameterValues("check");
		
		if (checks == null)
			return "redirect:/cartList";
		
		List<CartDTO> cartList = cartService.orderAllConfirm(Arrays.asList(checks));
		m.addAttribute("cartList", cartList);
		
		return "orderAllConfirm";
	}

	@RequestMapping("/cartOrderDone")//카트 번호를 이용한 단건 결제 처리
	public String cartOrderDone(OrderDTO oDTO, HttpSession session, @RequestParam(required = false) String orderNum) throws SQLException {
		cartService.orderDone(oDTO, orderNum);
		session.setAttribute("orderDTO", oDTO);
		
		return "orderDone";
	}

	@RequestMapping("/cartOrderConfirm")//카트 상품 주문, 카트번호를 이용한 단건 주문
	public ModelAndView cartOrderConfirm(@RequestParam(required = false)  String num) {
		ModelAndView mav = new ModelAndView();
		CartDTO cdto = cartService.cartbyNum(num);
		mav.addObject("cDTO", cdto);
		mav.setViewName("orderConfirm");

		return mav;
	}
	
	@RequestMapping("/orderConfirm")//상품 상세에서 바로 주문, 카트 번호 미이용 단건 주문
	public ModelAndView orderConfirm(GoodsDTO gDTO,
									@RequestParam("gSize") String gSize,
									@RequestParam("gColor") String gColor,
									@RequestParam("gAmount") String gAmount){

		ModelAndView mav = new ModelAndView();
		mav.addObject("gSize", gSize);
		mav.addObject("gColor", gColor);
		mav.addObject("gAmount", gAmount);				
		mav.addObject("gDTO", gDTO);
		mav.setViewName("orderConfirm");
		
		return mav;
	}

	@RequestMapping("/CartDelAll")//카트 모든 상품 삭제
	public String CartDelAll(HttpServletRequest request) {		
		String[] checked = request.getParameterValues("check");
		
		if (checked != null)
			cartService.cartAllDel(Arrays.asList(checked));
		
		return "redirect:/cartList";
	}

	@RequestMapping("/cartDelete")//카트 개별 상품 삭제
	public ResponseEntity<Void> cartDelete(@RequestParam("num") int num) {
		HttpStatus status = HttpStatus.OK;
		try {
			if (cartService.cartDel(num) == 0) status = HttpStatus.NOT_FOUND;
		} catch (Exception e) {
			e.printStackTrace();
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<Void>(status);
	}

	@RequestMapping("/cartUpdate")//카트 개별 상품 수량 변경
	public ResponseEntity<Void> cartUpdate(@RequestParam Map<String, Integer> map) {
		HttpStatus status = HttpStatus.OK;
		try {
			if (cartService.cartUpdate(map) == 0) status = HttpStatus.NOT_FOUND;
		} catch (Exception e) {
			e.printStackTrace();
			status = HttpStatus.INTERNAL_SERVER_ERROR;
		}
		
		return new ResponseEntity<Void>(status);
	}

	@RequestMapping("/cartList")
	public String cartList(HttpSession session, Model m) {
		String page = "cartList";
		
		try {
			MemberDTO dto = (MemberDTO) session.getAttribute("user");
			List<CartDTO> cartList = cartService.cartList(dto.getUserid());
			m.addAttribute("cartList", cartList);
		} catch (Exception e) {
			page = "redirect:/main";
		}
		
		return page;
	}

	@RequestMapping("/addCart")
	public String goodsCart(CartDTO cDTO, HttpSession session, Model m) {
		MemberDTO mDTO = (MemberDTO) session.getAttribute("user");

		String page = "redirect:/";
		if (mDTO != null) {
			cDTO.setUserid(mDTO.getUserid());
			cartService.cartAdd(cDTO);
			page = "redirect:/goodsRetrieve?gCode=" + cDTO.getgCode()+"&cart=Y";
		}
		return page;
	}

	@RequestMapping("/goodsList")
	public String goodsList(@RequestParam(value = "gCategory", required = false, defaultValue = "top")
							String gCategory,
							Model m) {
		/*
		 * 
		 * 
		 * 
		 */
		return "main";
	}

	@RequestMapping("/goodsRetrieve") 
	@ModelAttribute("item")  
	public GoodsDTO goodsRetrieve(@RequestParam("gCode") String gCode) {
		GoodsDTO dto = goodsService.goodsRetrieve(gCode);

		return dto;
	}

}
