package com.example.controller;

import java.util.List;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.ui.Model;
import org.springframework.web.bind.annotation.GetMapping;

import com.example.dto.GoodsDTO;
import com.example.service.GoodsService;

@Controller
public class MainController {

	@Autowired
	GoodsService goodsService;
	
	@GetMapping("/")
	public String index(Model m) {
		return "index";   
	}
	
	@GetMapping("/main")
	public String main(Model model) {
		List<GoodsDTO> goods = goodsService.goodsList();
		model.addAttribute("goods", goods);

		return "shopMain"; 
	}
}

