package com.example.service;

import java.sql.SQLException;
import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;
import org.springframework.transaction.annotation.Transactional;

import com.example.dao.CartDAO;
import com.example.dto.CartDTO;
import com.example.dto.OrderDTO;

@Service
public class CartServiceImpl implements CartService{

	@Autowired
	CartDAO dao;

	@Transactional
	public int orderAllDone(List<OrderDTO> x, List<String> nums) throws SQLException {
		for (int i = 0; i < nums.size(); i++) {
			CartDTO cartDTO = dao.cartbyNum(nums.get(i));
			OrderDTO orderDTO = x.get(i);
			orderDTO.setgCode(cartDTO.getgCode());
			orderDTO.setgName(cartDTO.getgName());
			orderDTO.setgPrice(cartDTO.getgPrice());
			orderDTO.setgSize(cartDTO.getgSize());
			orderDTO.setgColor(cartDTO.getgColor());
			orderDTO.setgAmount(cartDTO.getgAmount());
			orderDTO.setgImage(cartDTO.getgImage());
		}
		
		int n = dao.orderAllDone(x);
		if (n != dao.cartAllDel(nums))
			throw new SQLException();
		
		return n;
	}

	public List<CartDTO> orderAllConfirm(List<String> x) {
		return dao.orderAllConfirm(x);
	}

	@Transactional
	public int orderDone(OrderDTO dto, String orderNum) throws SQLException {
		int n = dao.orderDone(dto);
		if (orderNum != null && n != dao.cartDel(Integer.parseInt(orderNum)))
			throw new SQLException();
		
		return n;
	}

	public CartDTO cartbyNum(String num) {
		CartDTO dto = dao.cartbyNum(num);
		return dto;
	}

	public int cartAllDel(List<String> list) {
		return dao.cartAllDel(list);
	}

	public int cartDel(int num) {
		return dao.cartDel(num);
	}

	public int cartUpdate(Map<String, Integer> map) {
		return dao.cartUpdate(map);
	}

	public int cartAdd(CartDTO dto) {
		return dao.cartAdd(dto);
	}

	public List<CartDTO> cartList(String userid) {
		return dao.cartList(userid);
	}
}
