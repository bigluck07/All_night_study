$(document).ready(function(){

    	 //수정버튼
        $(".updateBtn").on("click",function(){
           	var num = this.dataset.xxx;
        	var gAmount = $("#cartAmount" + num).val();
        	var gPrice = this.dataset.price;
        	$.ajax({
				url: "cartUpdate",
				method: "get",
				data: {
					num,
					gAmount,
					gPrice
				},
				dataType : 'text', 
				success : function(responseData, status, xhr) {	
					alert("수량을 수정했습니다.");		
				},
				error : function(xhr, status, error) {
					console.log(xhr, status, error);
					alert("오류발생");	
				}
        	});//end ajax
        });
    	 
        //삭제버튼
        $(".delBtn").on("click",function(){
        	var num= $(this).attr("data-xxx");
        	var xxx = $(this);
        	$.ajax({
        		url:'cartDelete',
        		type:'get',
        		dataType:'text',
        		data:{
        			num:num
        		},
        		success:function(data,status,xhr){
        			location.reload();
        			alert("상품을 삭제했습니다.");
        		},
        		error:function(xhr,status,error){
        			console.log(xhr, status, error);
					alert("오류발생");
        		}
        	});//end ajax
        });
 
        $("#mainBtn").click(function(){
			location.href="/shop/main";
		});
		$("#logoutBtn").click(function() {			
			location.href = "/shop/logout";	
			alert("로그아웃 되었습니다.");		
		});
		$("#myPageBtn").click(function() {
			location.href = "/shop/mypage";
		});
		$("#cartListBtn").click(function() {
			location.href = "/shop/cartList";
		});
		
		
        //전체선택
        $("#allCheck").on("click",function(){
        	var checkBoxes = $(".check");
        	var flag = this.checked;
        	for (check of checkBoxes) {
        		check.checked = flag;
        	}
        });
        
       
        $("#delAllCart").on("click",function(){
        	
        	$("form").attr("action", "CartDelAll");
        	$("form").submit();// trigger
        });
        
       
        $(".orderBtn").on("click",function(){
        	var num= $(this).attr("data-xxx");
        	location.href="cartOrderConfirm?num="+num;
        });
     
        $("#orderAllConfirm").on("click",function(){
        	$("form").attr("action", "cartOrderAllConfirm");
        	$("form").submit();// trigger
        });
   });