package com.example.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.example.dto.MemberDTO;
import com.example.service.MemberService;

@Controller
public class LoginController {

	@Autowired
	MemberService service;
	
	@RequestMapping("/login")
	public String login(HttpServletRequest request, @RequestParam Map<String, String> map) {
		MemberDTO dto = service.login(map);
		if (dto == null) {
			request.setAttribute("title", "로그인 실패");
			request.setAttribute("action", "로그인");
			request.setAttribute("message", "로그인 실패");
			
			return "memberResult";
		} else {
			request.getSession().setAttribute("user", dto.getUserid());
			
			return "redirect:main";
		} 
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		session.invalidate();
				
		return "redirect:/";
	}
	
}





