package com.example.service;

import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.example.dao.MemberDAO;
import com.example.dto.MemberDTO;

@Service
public class MemberServiceImpl implements MemberService{

	@Autowired
	MemberDAO dao;
	
	public MemberDTO login(Map<String, String> map) {
		return dao.login(map);
	}
	
	public int idCheck(String userid) {
		return dao.idCheck(userid);
	}

	public int memberAdd(MemberDTO dto) {
		return dao.memberAdd(dto);
	}
	
	public MemberDTO mypage(String userid) {
		return dao.mypage(userid);
	}

	public int memberUpdate(MemberDTO dto) {
		return dao.memberUpdate(dto);
	}
}



