package com.example.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;

@Controller
public class TestController {

	//인터셉터 적용 안됨.
	@GetMapping("/main")
	public String main() {
		System.out.println("main>>>>>>>>>");
		return "main"; //  
	}
	
	//인터셉터 적용.
	@GetMapping("/login")
	public String login() {
		System.out.println("login>>>>>>>>>");
		return "main"; //  
	}
	@GetMapping("/cart")
	public String cart() {
		System.out.println("cart>>>>>>>>>");
		return "main"; //  
	}
}
