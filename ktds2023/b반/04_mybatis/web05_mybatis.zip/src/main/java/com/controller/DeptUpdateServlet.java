package com.controller;

import java.io.IOException;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.DeptDTO;
import com.service.DeptService;
import com.service.DeptServiceImpl;

/**
 * Servlet implementation class DeptListServlet
 */
@WebServlet("/DeptUpdateServlet")
public class DeptUpdateServlet extends HttpServlet {
	
	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		String deptno = request.getParameter("deptno");
		String dname = request.getParameter("dname");
		String loc = request.getParameter("loc");
		
		DeptDTO dto = new DeptDTO(Integer.parseInt(deptno),
				                  dname, loc);
		
		DeptService service = new DeptServiceImpl();
		try {
			int n = service.update(dto);
		} catch (Exception e) {
			e.printStackTrace();
		}

		// 화면처리 ( 부서작성후 목록보기 )
		response.sendRedirect("DeptListServlet"); //list.jsp 아님.
		
		
	}

	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		doGet(request, response);
	}

}
