package com.example.dao;

import java.util.List;
import com.example.dto.GoodsDTO;

public class GoodsDAO {

	public GoodsDTO goodsRetrieve(String gCode) {
		
		/*
		 * 
		 */
		
		return null;
	}

	public List<GoodsDTO> goodsList() {
		/*
		 * 
		 */
		return null;
	}
}
