$(function() {
	var signUpBtn = $('#signUpBtn');

	signUpBtn.click(function() {
		location.href = 'signUp';
	});
});