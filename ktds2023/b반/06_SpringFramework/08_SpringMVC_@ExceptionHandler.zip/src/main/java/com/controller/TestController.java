package com.controller;

import java.io.IOException;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.ExceptionHandler;
import org.springframework.web.bind.annotation.RequestMapping;

@Controller
public class TestController {

	@RequestMapping("/aaa")
	public String aaa() {
		//강제적으로 예외발생
		if(true) {
			throw new ArithmeticException("예외발생");
		}
		return "aaa";
	}
	@RequestMapping("/bbb")
	public String bbb() throws IOException{
		//강제적으로 예외발생
		if(true) {
			throw new IOException("예외발생");
		}
		return "aaa";
	}
	//발생된 예외를 catch
//	@ExceptionHandler({Exception.class})
	@ExceptionHandler({ArithmeticException.class, IOException.class})
	public String errorPage() {
		return "errorPage"; // /WEB-INF/views/errorPage.jsp
	}
	
}






