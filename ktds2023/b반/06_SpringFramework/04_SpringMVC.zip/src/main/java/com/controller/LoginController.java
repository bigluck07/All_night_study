package com.controller;

import java.util.Map;

import javax.servlet.http.HttpServletRequest;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dto.LoginDTO;

// POJO ( Plain Old Java Object )

@Controller
public class LoginController {

	// http://localhost:8090/app/loginForm 요청
	@RequestMapping("/loginForm")
	public String loginForm() {
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	@RequestMapping("/login")
	public String login(LoginDTO dto) {
	  System.out.println(dto);
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	
	@RequestMapping("/login5")
	public String login5(@RequestParam Map<String, String> map) {
		System.out.println(map);
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	
	@RequestMapping("/login4")
	public String login4(@RequestParam String userid,
			            @RequestParam String passwd) {
		System.out.println(userid+" " + passwd);
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	
	@RequestMapping("/login3")
	public String login3(@RequestParam("userid") String userid,
			            @RequestParam("passwd") String passwd) {
		System.out.println(userid+" " + passwd);
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	@RequestMapping("/login2")
	public String login2(HttpServletRequest request) {
		String userid = request.getParameter("userid");
		String passwd = request.getParameter("passwd");
		System.out.println(userid+" " + passwd);
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
}
