package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

import com.dto.LoginMultiDTO;

// POJO ( Plain Old Java Object )

@Controller
public class LoginMultiController {

	// http://localhost:8090/app/loginForm 요청
	@RequestMapping("/loginForm2")
	public String loginForm2() {
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	@RequestMapping("/loginMulti")
	public String login(LoginMultiDTO dto) {
		System.out.println(dto);
		
		return "loginForm";  //   /WEB-INF/views/loginForm.jsp
	}
	
}
