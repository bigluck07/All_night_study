package com.controller;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;

// POJO ( Plain Old Java Object )

@Controller
public class DeptController {

	// http://localhost:8090/app/list 요청
	//목록보기
	@RequestMapping("/list")
	public String list() {
		System.out.println("DeptController.list");
		return "list";  // 화면처리용의 논리적인 이름 ==> InternalResourceViewResolver 에 의해서
		                // /WEB-INF/views/ + list  + .jsp 조합해서 jsp 를 찾는다.
	}
	// http://localhost:8090/app/delete 요청
	@RequestMapping("/delete")
	public String delete() {
		System.out.println("DeptController.delete");
		return "delete";  // 화면처리용의 논리적인 이름 ==> InternalResourceViewResolver 에 의해서
		                // /WEB-INF/views/ + delete  + .jsp 조합해서 jsp 를 찾는다.
	}
	
}
