import org.springframework.context.ApplicationContext;
import org.springframework.context.support.GenericXmlApplicationContext;

import com.service.DeptServiceImpl;

public class SpringTest {

	public static void main(String[] args) {

		//spring 전 코드
		DeptServiceImpl service = 
				new DeptServiceImpl();
		
		//spring 코드
		/*
		 * 1. 빈 (DeptServiceImpl)을 작성
		 * 2. xml에 등록
		 * 3. IoC Container에게 xml 등록
		 *   ==> IoC Container는 빈 ( XXXXApplicationContext )
		 */
		ApplicationContext ctx =
				new GenericXmlApplicationContext("dept.xml");
		
		
	}

}
