package com.service;

public class DeptServiceImpl {

	public DeptServiceImpl() {
		System.out.println("DeptServiceImpl 생성자");
	}
}
