package com.service;

import java.util.List;

import com.dao.DeptDAO;

public class DeptServiceImpl {

	DeptDAO dao;
	
	// 생성자주입
	public DeptServiceImpl(DeptDAO dao) {
		//Spring 전 방식
//		this.dao = new DeptDAO();
		
		//Spring 방식
		System.out.println("생성자 호출");
		this.dao = dao;
	}
	
	public List<String> list(){
		return dao.list();
	}
	
}
