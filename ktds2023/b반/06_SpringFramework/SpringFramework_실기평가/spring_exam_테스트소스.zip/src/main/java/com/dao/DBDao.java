package com.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;

import com.dto.Notice;

public interface DBDao {

	public abstract List<Notice> selectList(SqlSessionTemplate session, Map<String, String> map);
	public abstract Notice selectByNo(SqlSessionTemplate session, int no);
	public abstract int noticeWrite(SqlSessionTemplate session, Notice notice);
	public abstract int noticeUpdate(SqlSessionTemplate session, Notice notice);
	public abstract int noticeDelete(SqlSessionTemplate session, int no);
}
