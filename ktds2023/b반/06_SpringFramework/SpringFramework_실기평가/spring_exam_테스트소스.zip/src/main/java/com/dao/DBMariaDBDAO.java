package com.dao;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.stereotype.Repository;

import com.dto.Notice;

@Repository
public class DBMariaDBDAO implements DBDao {

	@Override
	public List<Notice> selectList(SqlSessionTemplate session, Map<String, String> map) {
		return session.selectList("NoticeMapper.selectAll", map);
	}

	// 조회수 증가
	public int readCnt(SqlSessionTemplate session, int no) {
		return session.update("NoticeMapper.readCnt", no);
	}
	@Override
	public Notice selectByNo(SqlSessionTemplate session, int no) {
		//조회수 증가 메서드 호출
		int num = readCnt(session, no);
		return session.selectOne("NoticeMapper.selectByNo", no);
	}

	@Override
	public int noticeWrite(SqlSessionTemplate session, Notice notice) {
		return session.insert("NoticeMapper.noticeWrite", notice);
	}

	@Override
	public int noticeUpdate(SqlSessionTemplate session, Notice notice) {
		return session.update("NoticeMapper.noticeUpdate", notice);
	}

	@Override
	public int noticeDelete(SqlSessionTemplate session, int no) {
		return session.delete("NoticeMapper.noticeDelete", no);
	}

}
