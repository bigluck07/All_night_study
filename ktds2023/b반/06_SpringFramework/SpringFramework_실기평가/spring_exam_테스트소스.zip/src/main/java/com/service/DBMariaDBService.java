package com.service;

import java.util.List;
import java.util.Map;

import org.mybatis.spring.SqlSessionTemplate;
import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.dao.DBDao;
import com.dto.Notice;


@Service
public class DBMariaDBService implements DBService {

	
	@Autowired
	DBDao dao;
	
	@Autowired
	SqlSessionTemplate session;
	
	@Override
	public List<Notice> selectList(Map<String, String> map) {
		return dao.selectList(session, map);
	}

	@Override
	public Notice selectByNo(int no) {
		return dao.selectByNo(session, no);
	}

	@Override
	public int noticeWrite(Notice notice) {
		return dao.noticeWrite(session, notice);
	}

	@Override
	public int noticeUpdate(Notice notice) {
		return dao.noticeUpdate(session, notice);
	}

	@Override
	public int noticeDelete(int no) {
		return dao.noticeDelete(session, no);
	}

}
