package com.controller;

import javax.servlet.http.HttpSession;

import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.RequestMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.dto.MemberDTO;

@Controller
public class LoginController {

	@RequestMapping("/login")
	public String login(@RequestParam String userid,
			@RequestParam String passwd, HttpSession session ) {
		
		System.out.println("login 호출.....");
		
		// userid 와 passwd이용해서 DB연동해서 체크.
		// 모두 값이 일치한다고 가정한다. 따라서 HttpSession에 저장
		MemberDTO mem = new MemberDTO(userid, passwd, "홍길동", "서울");
		session.setAttribute("mem", mem);
		return "login";  // /WEB-INF/views/login.jsp
	}
	@RequestMapping("/mypage")
	public String mypage(HttpSession session) {
		
		System.out.println("mypage 호출.....");
		//세션이 사용여부확인해서 세션이 제거된 경우 다시 로그인하도록 유도
		MemberDTO mem = (MemberDTO)session.getAttribute("mem");
		if(mem == null) {
			//로그인을 안했거나 또는 로그인을 했지만 time-out 된 경우이다.
			return "redirect:loginForm";
		}
		
		return "mypage";  
	}
	
	@RequestMapping("/logout")
	public String logout(HttpSession session) {
		System.out.println("logout 호출.....");
		
		//세션이 사용여부확인해서 세션이 제거된 경우 다시 로그인하도록 유도
		MemberDTO mem = (MemberDTO)session.getAttribute("mem");
		if(mem == null) {
			//로그인을 안했거나 또는 로그인을 했지만 time-out 된 경우이다.
			return "redirect:loginForm";
		}else {
			session.invalidate();
		}
		
		return "loginForm";  
	}
}





