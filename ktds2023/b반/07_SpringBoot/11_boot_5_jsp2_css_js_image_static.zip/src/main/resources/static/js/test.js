
function go(){
 alert("hello");
}