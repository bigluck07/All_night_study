package com.example.controller;

import javax.persistence.EntityManager;
import javax.persistence.EntityManagerFactory;
import javax.persistence.EntityTransaction;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;

import com.example.entity.User;

@Controller
public class TestController {
	
	@Autowired
	EntityManagerFactory factory;

	@GetMapping("/insert")
	public String insert() {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		////////////////////////////////////////////
		//비영속성객체
		User user = new User(10L, "홍길동", 20);
		User user2 = new User(11L, "이순신", 30);
		//영속성객체로 만들기 위해서 저장한다.
		em.persist(user); //  JPA 가 자동으로 insert문을 생성해준다.
		em.persist(user2); //  JPA 가 자동으로 insert문을 생성해준다.
		
		////////////////////////////////////////////
		tx.commit(); // tx.rollback()
		return "main"; //  
	}
	
	@GetMapping("/find/{id}")
	public String find(@PathVariable Long id) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		////////////////////////////////////////////
		User user = em.find(User.class, id);
		System.out.println(user);
		////////////////////////////////////////////
		tx.commit(); // tx.rollback()
		return "main"; //  
	}
	
	@GetMapping("/delete/{id}")
	public String delete(@PathVariable Long id) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		////////////////////////////////////////////
		//삭제할 Entity를 검색 먼저 실행한다.
		User user = em.find(User.class, id);
		em.remove(user);
		////////////////////////////////////////////
		tx.commit(); // tx.rollback()
		return "main"; //  
	}
	@GetMapping("/update/{id}/{name}/{age}")
	public String update(@PathVariable Long id,
			             @PathVariable String name,
			             @PathVariable Integer age) {
		
		EntityManager em = factory.createEntityManager();
		EntityTransaction tx = em.getTransaction();
		tx.begin();
		////////////////////////////////////////////
		// 수정할 Entity를 검색 먼저 실행한다.
		User user = em.find(User.class, id);
		user.setName(name);
		user.setAge(age);
		////////////////////////////////////////////
		tx.commit(); // tx.rollback()
		return "main"; //  
	}
	
}







