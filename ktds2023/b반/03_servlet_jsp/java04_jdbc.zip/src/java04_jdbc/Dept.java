package java04_jdbc;

// VO(Value Object) DTO(Data Transfer Object)
// dept테이블의 하나의 행 저장용 클래스==> 패턴화 됨( DTO 패턴, VO 패턴, Domain패턴)
public class Dept {

	int deptno;
	String dname;
	String loc;
	
	public Dept() {
	}

	public Dept(int deptno, String dname, String loc) {
		this.deptno = deptno;
		this.dname = dname;
		this.loc = loc;
	}

	public int getDeptno() {
		return deptno;
	}

	public void setDeptno(int deptno) {
		this.deptno = deptno;
	}

	public String getDname() {
		return dname;
	}

	public void setDname(String dname) {
		this.dname = dname;
	}

	public String getLoc() {
		return loc;
	}

	public void setLoc(String loc) {
		this.loc = loc;
	}

	@Override
	public String toString() {
		return "Dept [deptno=" + deptno + ", dname=" + dname + ", loc=" + loc + "]";
	}
	
}
