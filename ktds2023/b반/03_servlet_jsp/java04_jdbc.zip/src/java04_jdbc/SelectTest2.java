package java04_jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;
import java.util.ArrayList;
import java.util.List;

public class SelectTest2 {

	public static void main(String[] args) throws Exception {

		//1. 4가지 정보 설정
		String driver ="org.mariadb.jdbc.Driver";  // jar 파일안에 있는 Driver 클래스명
		String url = "jdbc:mariadb://localhost:3306/ktds";
		String userid="root";
		String passwd="1234";
		
		//2. 문자열로 된 드라이버 객체 생성
		Class.forName(driver);
		
		//3. 연결 (java.sql.Connection )
		Connection con = DriverManager.getConnection(url, userid, passwd);
		System.out.println(con);
		
		//4. SQL문 작성 ==> 반드시 sql 문 마지막에 ; 제거 필수
		String sql = "select deptno as no, dname as name, loc from dept";
		
		//5. PreparedStatement ==> sql문 전송하기 위한 객체
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		//6.  sql문 전송
		/*
		 *  ArrayList<Dept> 에 저장해서 출력하시오
		 */
		List<Dept> list = new ArrayList<>();
		ResultSet rs = pstmt.executeQuery();
		while(rs.next()) {
			int deptno = rs.getInt("no");
			String dname = rs.getString("name");
			String loc = rs.getString(3);
			Dept dept = new Dept(deptno, dname, loc);
			//ArrayList 저장
			list.add(dept);
		}
		//ArrayList 출력
		for (Dept dept : list) {
			System.out.println(dept);
		}
		
		
		//7. 자원반납 -> close(); 반드시 역순으로
		rs.close();
		pstmt.close();
		con.close();
		
		/*
		 *   1) ResultSet rs =pstmt.executeQuery()
		 *       - select 문
		 *       
		 *     리턴값 ResultSet은 select 처리된 테이블를 객체화(클래스).  
		 *   2) int n = pstmt.executeUpdate()
		 *       - insert 
		 *       - delete
		 *       - update
		 * 
		 *      리턴값 n은 DML 처리된 행의 갯수가 저장된다.
		 */
		
	}//end main
}//end class
