package java04_jdbc;

import java.sql.Connection;
import java.sql.DriverManager;
import java.sql.PreparedStatement;
import java.sql.ResultSet;

public class UpdateTest {

	public static void main(String[] args) throws Exception {

		//1. 4가지 정보 설정
		String driver ="org.mariadb.jdbc.Driver";  // jar 파일안에 있는 Driver 클래스명
		String url = "jdbc:mariadb://localhost:3306/ktds";
		String userid="root";
		String passwd="1234";
		
		//2. 문자열로 된 드라이버 객체 생성
		Class.forName(driver);
		
		//3. 연결 (java.sql.Connection )
		Connection con = DriverManager.getConnection(url, userid, passwd);
		System.out.println(con);
		
		//4. SQL문 작성 ==> 반드시 sql 문 마지막에 ; 제거 필수
		String sql = "update dept set dname=? , loc=? where deptno=?";
		
		//5. PreparedStatement ==> sql문 전송하기 위한 객체
		PreparedStatement pstmt = con.prepareStatement(sql);
		
		//5.1 ? 대신에 값으로 치환
		pstmt.setInt(3, 99);
		pstmt.setString(1, "관리");
		pstmt.setString(2, "부산");
		// JDBC의 DML은 autocommit ==> 명시적으로 autocommit 비활성화 가능
		//6.  sql문 전송
		int n = pstmt.executeUpdate();
		System.out.println("적용된 행의 갯수:"+n);
		//7. 자원반납 -> close(); 반드시 역순으로
		pstmt.close();
		con.close();
		
		/*
		 *   1) ResultSet rs =pstmt.executeQuery()
		 *       - select 문
		 *       
		 *     리턴값 ResultSet은 select 처리된 테이블를 객체화(클래스).  
		 *   2) int n = pstmt.executeUpdate()
		 *       - insert 
		 *       - delete
		 *       - update
		 * 
		 *      리턴값 n은 DML 처리된 행의 갯수가 저장된다.
		 */
		
	}//end main
}//end class
