package com.servlet;

import java.io.IOException;
import java.util.ArrayList;
import java.util.List;

import javax.servlet.ServletConfig;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

// http://ip번호:포트번호/컨텍스트명/서블릿맵핑   (외우기)

public class LifeCycleServlet extends HttpServlet {
	
	int num = 0; // 인스턴스변수임에도 불구하고 누적(공유) 가능:  thread-unsafe
	List<String> list = new ArrayList<>();
	@Override
	public void init(ServletConfig config) throws ServletException {
		System.out.println("init >>");
	}

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
		num++;
		list.add("hello");
		System.out.println("LifeCycleServlet >>" + num + "\t" + list);
		
	}

}
