package com.controller;

import java.io.IOException;
import java.util.Arrays;
import java.util.List;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.Cookie;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

import com.dto.DeptDTO;

/**
 * Servlet implementation class AServlet
 */
@WebServlet("/Test3Servlet")
public class Test3Servlet extends HttpServlet {

	protected void doGet(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {

		//TestServlet URL
        // http://localhost:8090/app4/Test3Servlet
		
		//test.jsp
		//http://localhost:8090/app4/test.jsp
		/*
		 * The pathname specified may be relative, 
		 * although it cannot extend outside the current servlet context. 
		 * If the path begins with a "/" it is interpreted as relative 
		 * to the current context root.
		 */
		request.getRequestDispatcher("/test.jsp") // 절대경로 안됨. / 지정해도 상대경로로 처리됨.
		       .forward(request, response);
		
	}


	protected void doPost(HttpServletRequest request, HttpServletResponse response) throws ServletException, IOException {
	
		doGet(request, response);
	}

}
