package com.servlet;

import java.io.IOException;

import javax.servlet.RequestDispatcher;
import javax.servlet.ServletContext;
import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;
import javax.servlet.http.HttpSession;

@WebServlet("/setforward")
public class SetForwardServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		//scope에 데이터 저장 ( 기본형 및 참조형 모두 가능 )
		//1. request scope ( HttpServletRequest ), 요청 ~ 응답
		request.setAttribute("request", "request");
		
		//2. session scope (  HttpSession ) ==> 나중에 심화강의 , 브라우저시작 ~ 브라우저 종료
		HttpSession session = request.getSession();
		session.setAttribute("session", "session");
		
		//3. application scope ( ServletContext ) ==>   서버시작 ~ 서버종
		ServletContext application = getServletContext();
		application.setAttribute("application", "application");
		
		//포워드
		RequestDispatcher dis =request.getRequestDispatcher("get");
		dis.forward(request, response);
		
	}

}
