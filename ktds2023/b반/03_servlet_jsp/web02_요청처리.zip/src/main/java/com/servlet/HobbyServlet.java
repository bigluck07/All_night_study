package com.servlet;

import java.io.IOException;
import java.util.Arrays;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;


@WebServlet("/yyy")
public class HobbyServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request,
			HttpServletResponse response) throws ServletException, IOException {
		System.out.println("HobbyServlet"); 

		//checkbox 에서 선택된 값을 얻기
		String [] hobbies = request.getParameterValues("hobby");
		
		System.out.println(Arrays.toString(hobbies));
	}

}
