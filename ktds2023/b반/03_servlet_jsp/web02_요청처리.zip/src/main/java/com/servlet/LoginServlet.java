package com.servlet;

import java.io.IOException;
import java.io.PrintWriter;

import javax.servlet.ServletException;
import javax.servlet.annotation.WebServlet;
import javax.servlet.http.HttpServlet;
import javax.servlet.http.HttpServletRequest;
import javax.servlet.http.HttpServletResponse;

@WebServlet("/xxx")
public class LoginServlet extends HttpServlet {
	protected void doGet(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("LoginServlet:Get");
		// 사용자 입력 데이터 얻기 ( 폼데이터 얻기 )
		String id = request.getParameter("userid");
		String pw = request.getParameter("passwd");
		
		//응답처리
				response.setContentType("text/html;charset=UTF-8");
				
				PrintWriter out = response.getWriter();
				out.print("<html>");
				out.print("<body>");
				out.print("아이디:"+ id);
				out.print("비밀번호:"+ pw);
				out.print("</body>");
				out.print("</html>");
	}
	
	protected void doPost(HttpServletRequest request, 
			HttpServletResponse response) throws ServletException, IOException {
		
		System.out.println("LoginServlet:post");
		// 사용자 입력 데이터 얻기 ( 폼데이터 얻기 )
		// Post 는 한글처리 필수
		request.setCharacterEncoding("utf-8");
		
				String id = request.getParameter("userid");
				String pw = request.getParameter("passwd");
				
				//응답처리
						response.setContentType("text/html;charset=UTF-8");
						
						PrintWriter out = response.getWriter();
						out.print("<html>");
						out.print("<body>");
						out.print("아이디:"+ id);
						out.print("비밀번호:"+ pw);
						out.print("</body>");
						out.print("</html>");
	}

}
