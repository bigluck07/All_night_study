
public class ExceptionTest {

	public static void main(String[] args) {
		
		System.out.println("1");
		System.out.println("2");
		
		int num = 0;
		int result = 10/num;
		System.out.println("결과값:" + result);
		
		System.out.println("3");
		System.out.println("end");
	}

}
