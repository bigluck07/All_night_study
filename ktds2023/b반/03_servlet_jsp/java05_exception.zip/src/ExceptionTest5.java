class Test2{
	public void a() throws ArithmeticException, NullPointerException {
		b();
	}
	public void b() throws ArithmeticException, NullPointerException {
		int num = 0;
		int result = 10/num;
		System.out.println("결과값:"+ result);
		
		//여러 실행문장 있다고 가정...
	}
}//end Test
public class ExceptionTest5 {
	public static void main(String[] args) {
		System.out.println("start");
		Test2 t = new Test2();
	   try {	
		t.a();
	   }catch(ArithmeticException e) { //발생된 모든 예외정보는 e변수가 가짐.
//		   System.out.println(e.getMessage());
		   e.printStackTrace(); // 개발자의 디버깅용으로 주로 사용됨.
	   }catch(NullPointerException e) { //발생된 모든 예외정보는 e변수가 가짐.
		   e.printStackTrace(); // 개발자의 디버깅용으로 주로 사용됨.
	   }catch(Exception e) { //발생된 모든 예외정보는 e변수가 가짐.
		   e.printStackTrace(); // 개발자의 디버깅용으로 주로 사용됨.
	   }
		System.out.println("end");
	}
}
