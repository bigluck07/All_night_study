
public class ExceptionTest3 {

	public static void main(String[] args) {
		
		System.out.println("1");
		System.out.println("2");
		
		try {
			int num = 0;
			int result = 10/num;
			System.out.println("결과값:" + result);
			
			//하위에 여러 실행문장이 있다고 가정
			// ...
		}catch(ArithmeticException e) { // 다형성적용가능. (RuntimeException, Exception 모두 가능)
			//예외가 발생된 이유를 친철하게 설명하는 것이 가장 좋은 예외처리방법이다.
			System.out.println("0으로 나누어서 예외발생됨.");
		}catch(NullPointerException e) { // 다형성적용가능. (RuntimeException, Exception 모두 가능)
			System.out.println("null 값으로 인한 예외발생됨.");
		}catch(Exception e) { 
			System.out.println("나머지 예외발생은 여기서 처리됨. ");
		}finally {
			System.out.println("반드시 수행되는 문장");
		}
		
		System.out.println("3");
		System.out.println("end"); // 정상종료
	}

}
