
public class ExceptionTest2 {

	public static void main(String[] args) {
		
		System.out.println("1");
		System.out.println("2");
		
		try {
			int num = 2;
			int result = 10/num;
			System.out.println("결과값:" + result);
		}catch(ArithmeticException e) { // 다형성적용가능. (RuntimeException, Exception 모두 가능)
			//예외가 발생된 이유를 친철하게 설명하는 것이 가장 좋은 예외처리방법이다.
			System.out.println("0으로 나누어서 예외발생됨.");
		}
		
		System.out.println("3");
		System.out.println("end"); // 정상종료
	}

}
