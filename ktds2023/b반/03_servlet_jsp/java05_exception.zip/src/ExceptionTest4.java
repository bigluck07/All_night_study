class Test{
	public void a() throws ArithmeticException {
		b();
	}
	public void b() throws ArithmeticException {
		int num = 0;
		int result = 10/num;
		System.out.println("결과값:"+ result);
	}
}//end Test
public class ExceptionTest4 {
	public static void main(String[] args) {
		System.out.println("start");
		Test t = new Test();
	   try {	
		t.a();
	   }catch(ArithmeticException e) { //발생된 모든 예외정보는 e변수가 가짐.
//		   System.out.println(e.getMessage());
		   e.printStackTrace(); // 개발자의 디버깅용으로 주로 사용됨.
	   }
		System.out.println("end");
	}
}
