package com.ktds.app.exception;

public class NoSuchQnaException extends RuntimeException {

	public NoSuchQnaException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchQnaException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
