package com.ktds.app.board.controller;

import java.util.List;
import java.util.Map;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.ModelAttribute;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.RequestParam;

import com.ktds.app.board.controller.dto.BoardDto;
import com.ktds.app.board.controller.dto.BoardRegisterRequest;
import com.ktds.app.board.controller.dto.BoardUpdateRequest;
import com.ktds.app.board.service.BoardService;

@Controller
public class BoardController {
	
	private final BoardService service;
	
	@Autowired
	public BoardController(BoardService service) {
		this.service = service;
	}
	

	@GetMapping("/home")
	public String home() {
		return "index";
	}
	
	@GetMapping("/list")
	@ModelAttribute("list")
	public List<BoardDto> qnaList(@RequestParam Map<String, String> searchOption) throws Exception {
		return service.getQnas(searchOption);
	}
	
	@GetMapping("/write")
	public String registerPage() {
		return "writeForm";
	}
	@PostMapping("/write")
	public String registerQna(BoardRegisterRequest req) throws Exception {
		service.registerQna(req);
		return "redirect:list";
	}
	
	@GetMapping("/retrieve")
	@ModelAttribute("qna")
	public BoardDto getQna(@RequestParam Long no) throws Exception {
		return service.getQna(no);
	}
	
	@PostMapping("/update")
	public String updateQna(BoardUpdateRequest req) throws Exception {
		service.updateQna(req);
		return "redirect:list";
	}
	
	@GetMapping("/delete")
	public String deleteQna(@RequestParam Long no) throws Exception {
		service.deleteQna(no);
		return "redirect:list";
	}
	
}
