package com.ktds.app.board;

import java.time.LocalDateTime;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.FetchType;
import javax.persistence.GeneratedValue;
import javax.persistence.GenerationType;
import javax.persistence.Id;
import javax.persistence.JoinColumn;
import javax.persistence.ManyToOne;

import org.hibernate.annotations.ColumnDefault;
import org.hibernate.annotations.DynamicInsert;

import com.ktds.app.board.controller.dto.BoardUpdateRequest;
import com.ktds.app.member.Member;

@Entity
@DynamicInsert
public class Board {

	@Id @GeneratedValue(strategy = GenerationType.IDENTITY)
	private Long no;
	
	@ManyToOne(fetch = FetchType.LAZY)
	@JoinColumn(name = "userid")
	private Member member;
	
	@Column(nullable = false)
	private String username;
	
	@Column(nullable = false)
	private String title;
	
	private String content;
	
	@ColumnDefault("NOW()")
	private LocalDateTime writeday;
	
	@ColumnDefault("0")
	private Long readcnt;

	public Board() {}
	public Board(Member member, String username, String title, String content) {
		this.member = member;
		this.username = username;
		this.title = title;
		this.content = content;
	}

	
	public void increaseHits() {
		++readcnt;
	}
	
	public void update(BoardUpdateRequest req) {
		title = req.getTitle();
		content = req.getContent();
	}
	
	
	public Long getNo() {
		return no;
	}
	public void setNo(Long no) {
		this.no = no;
	}
	public Member getMember() {
		return member;
	}
	public void setMember(Member member) {
		this.member = member;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public LocalDateTime getWriteday() {
		return writeday;
	}
	public void setWriteday(LocalDateTime writeday) {
		this.writeday = writeday;
	}
	public Long getReadcnt() {
		return readcnt;
	}
	public void setReadcnt(Long readcnt) {
		this.readcnt = readcnt;
	}
	
}
