package com.ktds.app.exception;

import org.springframework.web.bind.annotation.ControllerAdvice;
import org.springframework.web.bind.annotation.ExceptionHandler;

@ControllerAdvice
public class GlobalExceptionHandler {
	
	@ExceptionHandler({ Exception.class })
	public String exception(Exception e) {
		System.out.println("Resolved Exception >>>>>> " + e.getMessage());
		return "error";
	}

}
