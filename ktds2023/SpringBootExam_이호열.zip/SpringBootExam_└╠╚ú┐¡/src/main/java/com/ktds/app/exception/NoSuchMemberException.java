package com.ktds.app.exception;

public class NoSuchMemberException extends RuntimeException {

	public NoSuchMemberException() {
		super();
		// TODO Auto-generated constructor stub
	}

	public NoSuchMemberException(String message) {
		super(message);
		// TODO Auto-generated constructor stub
	}

	
}
