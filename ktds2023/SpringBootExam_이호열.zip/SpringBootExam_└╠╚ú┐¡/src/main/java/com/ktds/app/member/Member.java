package com.ktds.app.member;

import javax.persistence.Column;
import javax.persistence.Entity;
import javax.persistence.Id;

@Entity
public class Member {

	@Id	
	private String userid;
	
	@Column(nullable = false)
	private String passwd;
	@Column(nullable = false)
	private String username;

	private String email;
	private String phone;
	
	public Member() {}
	public Member(String userid, String passwd, String username, String email, String phone) {
		this.userid = userid;
		this.passwd = passwd;
		this.username = username;
		this.email = email;
		this.phone = phone;
	}
	
	
	public void login(String password) throws RuntimeException {
		if (!this.passwd.equals(password))
			throw new RuntimeException("Wrong password");
	}
	
	
	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}
	
}
