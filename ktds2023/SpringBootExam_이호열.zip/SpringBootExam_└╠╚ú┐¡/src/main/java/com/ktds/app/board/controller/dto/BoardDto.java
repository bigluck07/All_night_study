package com.ktds.app.board.controller.dto;

import java.time.LocalDateTime;

import com.ktds.app.board.Board;
import com.ktds.app.member.Member;

public class BoardDto {

	private Long no;
	private String title;
	private String content;
	private String username;
	private LocalDateTime writeday;
	private Long readcnt;
	
	public BoardDto(Long no, String title, String content, String username, LocalDateTime writeday, Long readcnt) {
		this.no = no;
		this.title = title;
		this.content = content;
		this.username = username;
		this.writeday = writeday;
		this.readcnt = readcnt;
	}
	
	
	public Long getNo() {
		return no;
	}
	public void setNo(Long no) {
		this.no = no;
	}
	public String getTitle() {
		return title;
	}
	public void setTitle(String title) {
		this.title = title;
	}
	public String getContent() {
		return content;
	}
	public void setContent(String content) {
		this.content = content;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public LocalDateTime getWriteday() {
		return writeday;
	}
	public void setWriteday(LocalDateTime writeday) {
		this.writeday = writeday;
	}
	public Long getReadcnt() {
		return readcnt;
	}
	public void setReadcnt(Long readcnt) {
		this.readcnt = readcnt;
	}
	
	
	public static BoardDto toDto(Board entity) {
		return new BoardDto(
				entity.getNo(), 
				entity.getTitle(),
				entity.getContent(),
				entity.getMember().getUsername(), 
				entity.getWriteday(), 
				entity.getReadcnt());
	}
	
}
