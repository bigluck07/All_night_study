package com.ktds.app.member.service;

import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Service;

import com.ktds.app.exception.NoSuchMemberException;
import com.ktds.app.member.Member;
import com.ktds.app.member.controller.dto.LoginRequest;
import com.ktds.app.member.controller.dto.MemberDto;
import com.ktds.app.member.controller.dto.MemberRegisterRequest;
import com.ktds.app.member.repository.MemberRepository;

@Service
public class MemberService {
	
	private final MemberRepository repo;
	
	@Autowired
	public MemberService(MemberRepository repo) {
		this.repo = repo;
	}
	
	
	public MemberDto login(LoginRequest req) throws Exception {
		Member member = repo.findById(req.getUserid())
				.orElseThrow(() -> new NoSuchMemberException("No such member with userid " + req.getUserid()));
		
		member.login(req.getPasswd());
		return MemberDto.toDto(member);
	}
	
	public MemberDto getMember(String userid) throws Exception {
		return MemberDto.toDto(repo.findById(userid).orElse(null));
	}
	
	@Transactional
	public void registerMember(MemberRegisterRequest req) throws Exception {
		repo.save(
				new Member(req.getUserid(), req.getPasswd(), req.getUsername(), req.getEmail(), req.getPhone()));
	}

}
