package com.ktds.app.member.controller;

import javax.servlet.http.HttpSession;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.stereotype.Controller;
import org.springframework.web.bind.annotation.GetMapping;
import org.springframework.web.bind.annotation.PathVariable;
import org.springframework.web.bind.annotation.PostMapping;
import org.springframework.web.bind.annotation.ResponseBody;

import com.ktds.app.member.controller.dto.LoginRequest;
import com.ktds.app.member.controller.dto.MemberDto;
import com.ktds.app.member.controller.dto.MemberRegisterRequest;
import com.ktds.app.member.service.MemberService;

@Controller
public class MemberController {
	
	private final MemberService service;
	
	@Autowired
	public MemberController(MemberService service) {
		this.service = service;
	}
	

	@GetMapping("/login")
	public String loginPage() {
		return "loginForm";
	}
	@PostMapping("/login")
	public String login(LoginRequest req, HttpSession sess) throws Exception {
		MemberDto loginMember = service.login(req);
		sess.setAttribute("member", loginMember);
		return "index";
	}
	@GetMapping("/logout")
	public String logout(HttpSession sess) {
		sess.invalidate();
		return "index";
	}
	
	@GetMapping("/memberAdd")
	public String registerPage() {
		return "memberForm";
	}
	@PostMapping("/memberAdd")
	public String registerMember(MemberRegisterRequest req) throws Exception {
		service.registerMember(req);
		return "index";
	}
	
	@GetMapping("/members/{userid}")
	@ResponseBody
	public MemberDto getMember(@PathVariable String userid) throws Exception {
		return service.getMember(userid);
	}
	
	@GetMapping("/mypage")
	public String myPage() {
		return "mypage";
	}
	
}
