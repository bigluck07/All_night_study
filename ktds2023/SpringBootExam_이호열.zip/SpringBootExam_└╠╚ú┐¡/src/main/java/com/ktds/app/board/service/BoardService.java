package com.ktds.app.board.service;

import java.util.ArrayList;
import java.util.List;
import java.util.Map;
import java.util.stream.Collectors;

import javax.persistence.criteria.Predicate;
import javax.transaction.Transactional;

import org.springframework.beans.factory.annotation.Autowired;
import org.springframework.data.jpa.domain.Specification;
import org.springframework.stereotype.Service;
import org.springframework.util.StringUtils;

import com.ktds.app.board.Board;
import com.ktds.app.board.controller.dto.BoardDto;
import com.ktds.app.board.controller.dto.BoardRegisterRequest;
import com.ktds.app.board.controller.dto.BoardUpdateRequest;
import com.ktds.app.board.repository.BoardRepository;
import com.ktds.app.exception.NoSuchMemberException;
import com.ktds.app.exception.NoSuchQnaException;
import com.ktds.app.member.Member;
import com.ktds.app.member.repository.MemberRepository;

@Service
public class BoardService {

	private final BoardRepository repo;
	private final MemberRepository memberRepo;
	
	@Autowired
	public BoardService(BoardRepository repo, MemberRepository memberRepo) {
		this.repo = repo;
		this.memberRepo = memberRepo;
	}
	
	
	public List<BoardDto> getQnas(Map<String, String> searchOption) throws Exception {
		return repo.findAll(searchWith(searchOption)).stream()
				.map(BoardDto::toDto)
				.collect(Collectors.toList());
	}
	private static Specification<Board> searchWith(final Map<String, String> searchOption) {
		return ((root, query, builder) -> {
			List<Predicate> predicates = new ArrayList<>();
			final String searchName = searchOption.get("searchName");
			
			if (StringUtils.hasText(searchName))
				predicates.add(builder.like(root.get(searchName), "%" + searchOption.get("searchValue") + "%"));
			
			return builder.and(predicates.toArray(new Predicate[0]));
		});
	}
	
	@Transactional
	public BoardDto getQna(Long no) throws Exception {
		Board qna = repo.findById(no)
				.orElseThrow(() -> new NoSuchQnaException("No such QnA with no " + no));
		
		qna.increaseHits();
		return BoardDto.toDto(qna);
	}
	
	@Transactional
	public void registerQna(BoardRegisterRequest req) throws Exception {
		Member writer = memberRepo.findByUsername(req.getUsername())
				.orElseThrow(() -> new NoSuchMemberException("No such member with username " + req.getUsername()));
		
		repo.save(new Board(writer, req.getUsername(), req.getTitle(), req.getContent()));
	}
	
	@Transactional
	public void updateQna(BoardUpdateRequest req) throws Exception {
		Board qna = repo.findById(req.getNo())
				.orElseThrow(() -> new NoSuchQnaException("No such QnA with no " + req.getNo()));
		
		qna.update(req);
	}
	
	@Transactional
	public void deleteQna(Long no) throws Exception {
		repo.deleteById(no);
	}
	
}
