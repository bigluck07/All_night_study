package com.ktds.app.board.controller.dto;

public class BoardUpdateRequest extends BoardRegisterRequest {

	private Long no;

	public Long getNo() {
		return no;
	}
	public void setNo(Long no) {
		this.no = no;
	}
	
}
