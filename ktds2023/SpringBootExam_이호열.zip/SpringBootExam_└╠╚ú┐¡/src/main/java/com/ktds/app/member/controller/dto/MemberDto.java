package com.ktds.app.member.controller.dto;

import com.ktds.app.member.Member;

public class MemberDto {

	private String userid;
	private String passwd;
	private String username;
	private String email;
	private String phone;
	
	public MemberDto(String userid, String passwd, String username, String email, String phone) {
		this.userid = userid;
		this.passwd = passwd;
		this.username = username;
		this.email = email;
		this.phone = phone;
	}


	public String getUserid() {
		return userid;
	}
	public void setUserid(String userid) {
		this.userid = userid;
	}
	public String getPasswd() {
		return passwd;
	}
	public void setPasswd(String passwd) {
		this.passwd = passwd;
	}
	public String getUsername() {
		return username;
	}
	public void setUsername(String username) {
		this.username = username;
	}
	public String getEmail() {
		return email;
	}
	public void setEmail(String email) {
		this.email = email;
	}
	public String getPhone() {
		return phone;
	}
	public void setPhone(String phone) {
		this.phone = phone;
	}

	public static MemberDto toDto(Member entity) {
		if (entity == null) return null;
		return new MemberDto(entity.getUserid(), entity.getPasswd(), entity.getUsername(), entity.getEmail(), entity.getPhone());
	}
	
}
